import SwiftUI
import UIKit

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @State private var tabNavigation: AppTabNavigationState
    @State private var launchStage = 0 // 0 = brújula, 1 = solicitar key, 2 = aplicación
    @State private var accessText = ""
    @State private var showingOriginalApp = false
    @AppStorage(FeatureVisibility.cleanerStorageKey) private var cleanerEnabled = true
    @AppStorage(FeatureVisibility.wallpapersStorageKey) private var wallpapersEnabled = true

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-files-tab") {
            initialTab = 1
        } else if arguments.contains("--simulate-patch-tab") {
            initialTab = 2
        } else if arguments.contains("--simulate-cleaner-tab") {
            initialTab = 3
        } else if arguments.contains("--simulate-wallpaper-tab") {
            initialTab = 4
        } else {
            initialTab = AppSection.patches.rawValue
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
#else
        _tabNavigation = State(initialValue: AppTabNavigationState())
#endif
    }

    var body: some View {
        Group {
            if launchStage == 0 {
                CompassGateView {
                    withAnimation(.easeInOut(duration: 0.25)) { launchStage = 1 }
                }
            } else if launchStage == 1 {
                DOURKeyEntryView(accessText: $accessText) {
                    withAnimation(.easeInOut(duration: 0.25)) { launchStage = 2 }
                }
            } else {
                PatchProjectsView(ghostTheme: true)
            }
        }
        .background(Color.black.ignoresSafeArea())
        .statusBarHidden(true)
        .tint(AppTheme.accent)
        .imageScale(.small)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: cleanerEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onChange(of: wallpapersEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("3105")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            DashboardView(
                cleanerEnabled: $cleanerEnabled,
                wallpapersEnabled: $wallpapersEnabled,
                wallpapersSupported: wallpapersSupported
            )
        case .files:
            AppDataBrowserView(
                tabSession: filesTabSession
            )
        case .patches:
            PatchProjectsView(ghostTheme: true)
        case .cleaner:
            CleanerView()
        case .wallpapers:
            WallpaperLabView()
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(
            cleanerEnabled: cleanerEnabled,
            wallpapersEnabled: wallpapersEnabled,
            wallpapersSupported: wallpapersSupported
        )
    }

    private var wallpapersSupported: Bool {
        WallpaperFeatureSupportPolicy.isSupported(major: AppInfo.versionTuple.major)
    }

    private var selectedVisibleSection: AppSection {
        guard let section = AppSection(rawValue: tabNavigation.selectedTab),
              featureVisibility.isVisible(section) else {
            return .patches
        }
        return section
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .files: return "tab.files"
        case .patches: return "tab.patches"
        case .cleaner: return "tab.cleaner"
        case .wallpapers: return "tab.wallpapers"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .files: return "folder.fill"
        case .patches: return "shippingbox.fill"
        case .cleaner: return "sparkles"
        case .wallpapers: return "photo.on.rectangle.angled"
        }
    }
}

private struct DashboardView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var showLogs = false
    @Binding var cleanerEnabled: Bool
    @Binding var wallpapersEnabled: Bool
    let wallpapersSupported: Bool

    var body: some View {
        NavigationStack {
            List {
                deviceSection
                featuresSection
            }
            .navigationBarTitleDisplayMode(.inline)
            .tint(AppTheme.accent)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showLogs = true } label: {
                        Image(systemName: "apple.terminal")
                    }
                    .accessibilityLabel(language.text("accessibility.open_logs"))
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Link(destination: URL(string: "https://t.me/+6L89Qcso3w9kN2Yx")!) {
                        Image(systemName: "paperplane.fill")
                            .foregroundStyle(.cyan)
                    }
                    .accessibilityLabel("Abrir grupo de Telegram")
                }
            }
            .sheet(isPresented: $showSettings) { SettingsView() }
            .sheet(isPresented: $showLogs) { LogView() }
        }
    }

    private var featuresSection: some View {
        Section {
            Toggle(isOn: $cleanerEnabled) {
                Label(language.text("tab.cleaner"), systemImage: "sparkles")
            }
            if wallpapersSupported {
                Toggle(isOn: $wallpapersEnabled) {
                    Label(language.text("tab.wallpapers"), systemImage: "photo.on.rectangle.angled")
                }
            }
        } header: {
            Text(language.text("dashboard.features"))
        } footer: {
            Text(language.text("dashboard.features_footer"))
        }
    }

    private var deviceSection: some View {
        Section {
            LabeledContent(language.text("dashboard.hardware_model")) {
                Text(AppInfo.displayMachineName)
                    .font(.body.monospaced())
            }
            LabeledContent(language.text("settings.ios_version")) {
                Text("\(AppInfo.osVersion) (\(AppInfo.osBuild))")
                    .font(.body.monospaced())
            }
            HStack {
                Text(language.text("settings.compatibility"))
                Spacer()
                Text(language.text(appState.isSupported ? "settings.supported" : "settings.unsupported"))
                .foregroundStyle(appState.isSupported ? Color.green : Color.red)
            }

            if appState.kernelExploitApplicable && AppInfo.versionTuple.major < 26 {
                HStack {
                    Text(language.text("dashboard.kernel_status"))
                    Spacer()
                    if appState.kernelExploitRunning {
                        HStack(spacing: 6) {
                            ProgressView().controlSize(.small)
                            Text(language.text("dashboard.kernel_running"))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    } else {
                        Text(language.text(appState.exploitStatus.isSuccess ? "dashboard.kernel_active" : "dashboard.kernel_inactive"))
                        .foregroundStyle(appState.exploitStatus.isSuccess ? Color.green : Color.secondary)
                    }
                }
            }
        } header: {
            Text(language.text("common.device"))
        } footer: {
            Text(language.text("settings.supported_range_summary"))
        }
    }
}


// MARK: - Compass gate and DOUR key entry

private struct CompassGateView: View {
    let onReachTarget: () -> Void
    @State private var heading: Double = 315
    @State private var dragStartHeading: Double = 315
    @State private var hasOpenedKey = false

    private let targetHeading = 210.0

    var body: some View {
        GeometryReader { geometry in
            let dialSize = min(geometry.size.width - 54, min(geometry.size.height * 0.52, 430))
            VStack(spacing: 0) {
                Spacer(minLength: 22)
                CompassDial(heading: heading, size: dialSize)
                    .contentShape(Circle())
                    .gesture(
                        RotationGesture()
                            .onChanged { value in
                                heading = normalized(dragStartHeading + value.degrees)
                                checkTarget()
                            }
                            .onEnded { value in
                                heading = normalized(dragStartHeading + value.degrees)
                                dragStartHeading = heading
                                checkTarget()
                            }
                    )
                    .accessibilityLabel("Brújula ajustable. Gira hasta 210 grados")

                Text(String(format: "%.0f° %@", heading, compassDirection(heading)))
                    .font(.system(size: min(geometry.size.width * 0.13, 66), weight: .light, design: .rounded))
                    .monospacedDigit()
                    .foregroundStyle(.white)
                    .padding(.top, 42)

                VStack(spacing: 8) {
                    Text("38°53′23″ N  77°00′32″ O")
                    Text("Washington, Estados Unidos")
                    Text("30 pies de altitud")
                }
                .font(.system(size: 17, weight: .regular, design: .rounded))
                .foregroundStyle(.white.opacity(0.94))
                .multilineTextAlignment(.center)
                .padding(.top, 22)

                Text("Gira la brújula hasta 210°")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(.white.opacity(0.55))
                    .padding(.top, 24)
                Spacer(minLength: 28)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.black.ignoresSafeArea())
        }
        .preferredColorScheme(.dark)
    }

    private func checkTarget() {
        guard !hasOpenedKey, angularDistance(heading, targetHeading) <= 2 else { return }
        hasOpenedKey = true
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18, execute: onReachTarget)
    }

    private func normalized(_ value: Double) -> Double {
        let result = value.truncatingRemainder(dividingBy: 360)
        return result < 0 ? result + 360 : result
    }

    private func angularDistance(_ a: Double, _ b: Double) -> Double {
        let difference = abs(normalized(a) - normalized(b))
        return min(difference, 360 - difference)
    }

    private func compassDirection(_ value: Double) -> String {
        let directions = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSO", "SO", "OSO", "O", "ONO", "NO", "NNO"]
        return directions[Int((normalized(value) / 22.5).rounded()) % 16]
    }
}

private struct CompassDial: View {
    let heading: Double
    let size: CGFloat

    var body: some View {
        ZStack {
            Circle().stroke(Color.white.opacity(0.9), lineWidth: 1.2)
            ForEach(0..<120, id: \.self) { tick in
                Capsule()
                    .fill(Color.white.opacity(tick.isMultiple(of: 10) ? 1 : 0.88))
                    .frame(width: tick.isMultiple(of: 10) ? 2.5 : 1.1,
                           height: tick.isMultiple(of: 10) ? size * 0.065 : size * 0.035)
                    .offset(y: -size * 0.455)
                    .rotationEffect(.degrees(Double(tick) * 3))
            }
            compassLabel("N", x: 0, y: -size * 0.25)
            compassLabel("E", x: size * 0.25, y: size * 0.25)
            compassLabel("S", x: 0, y: size * 0.25)
            compassLabel("O", x: -size * 0.25, y: -size * 0.25)

            Circle()
                .fill(Color(white: 0.12))
                .frame(width: size * 0.30, height: size * 0.30)
            Path { path in
                path.move(to: CGPoint(x: size / 2, y: size * 0.22))
                path.addLine(to: CGPoint(x: size / 2, y: size * 0.78))
                path.move(to: CGPoint(x: size * 0.22, y: size / 2))
                path.addLine(to: CGPoint(x: size * 0.78, y: size / 2))
            }
            .stroke(Color.white.opacity(0.55), lineWidth: 0.8)
            Circle().stroke(Color.white.opacity(0.45), lineWidth: 0.8)
                .frame(width: 24, height: 24)

            Image(systemName: "triangle.fill")
                .font(.system(size: 21, weight: .bold))
                .foregroundStyle(.red)
                .offset(y: -size * 0.50)
                .rotationEffect(.degrees(heading))
        }
        .frame(width: size, height: size)
    }

    private func compassLabel(_ title: String, x: CGFloat, y: CGFloat) -> some View {
        Text(title)
            .font(.system(size: size * 0.085, weight: .regular))
            .foregroundStyle(.white)
            .offset(x: x, y: y)
    }
}

private struct DOURKeyEntryView: View {
    @Binding var accessText: String
    let onContinue: () -> Void

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 20) {
                Spacer()
                Text("DOUR")
                    .font(.system(size: 44, weight: .black, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(Color(red: 0.16, green: 0.88, blue: 0.43))

                TextField("Ingrese su key", text: $accessText)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.white)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(.horizontal, 22)
                    .frame(height: 64)
                    .background(Color.white.opacity(0.07))
                    .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.2), lineWidth: 1))
                    .clipShape(RoundedRectangle(cornerRadius: 18))

                Button(action: onContinue) {
                    Text("CONTINUAR")
                        .font(.system(size: 18, weight: .black, design: .rounded))
                        .tracking(2)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 66)
                        .background(Color(red: 0.10, green: 0.72, blue: 0.34), in: RoundedRectangle(cornerRadius: 20))
                }
                .buttonStyle(.plain)
                Spacer()
            }
            .padding(.horizontal, 30)
            .frame(maxWidth: 520)
        }
        .preferredColorScheme(.dark)
    }
}
